#include<iostream>
#include<set>
#include<stack>

bool display=false;
using namespace std;
stack<int>finalstack;
int** parr;
const int infinity=int(1e10);
set <pair<int,int>> Set;  //For Storing Neighbour vertices of Each Vertex
set<pair<int,int>> Path;//FOR MAKING PAIR OF VERTICES WHICH HAS EDGE IN MINIMUM SPANNING TREE
//Function for finding minimum best path
int findMinIndex(const int arr[], int size) {
	
    int minIndex = 0;

    for (int i = 1; i < size; i++) {
        if (arr[i] < arr[minIndex]) {
            minIndex = i;
        }
    }

    return minIndex;
}
void Add_edge(int x,int y)
{//function for adding edge in path
				for(auto i=Path.begin();i!=Path.end();i++)
				{
						if( y==(*i).second){
						Path.erase(i);
						break;}
														
				}
		
				Path.insert(make_pair(x,y));
	
}
void Dijkstras(int** graph,int* Distance,bool*Recorded ,int vertex,int source)
	{   //Function for calculating Minimum Distance from source to all Vertex
		 
		
		
		
		
			//entering pair of element in set which  neighbour to the current vertex which is spanning
		//Format(distance,destination vertex)
			
			Set.insert(make_pair(0,source));
			Distance[source]=0;
			while(!Set.empty())
			{
				
			auto firstPair = *Set.begin();
					int Ver = firstPair.second;
		

				for(int i=0;i<vertex;i++){
				
					if(Recorded[Ver]==true){break;}
					if(graph[Ver][i]!=infinity ){
		
						Set.insert(make_pair(graph[Ver][i],i));
						
					//updating Distance of vertex if shortest Distance found	
					if(Distance[i]>Distance[Ver]+graph[Ver][i]){
					
						
						Add_edge(Ver,i);
						Distance[i]=Distance[Ver]+graph[Ver][i];
					//Marking all Vertex to false whose distance is updated 
						Recorded[i]=false;
						
						}}
						
						}
						//Record the Vertex Which Span to stop more than one spanning round each vertex
				Recorded[Ver]=1;
				Set.erase(firstPair);
			
				}
 }
	void Path_Finder(int source,int Vertex,int des,bool display)	
  {//For finding and displaying minimum path from source to destination vertex
	int patharr[Vertex][Vertex];
	//initializing at 0
	for(int i=0;i<Vertex;i++){for(int j=0;j<Vertex;j++){patharr[i][j]=0;}}
	
	
	//entering tree
	for(auto i=Path.begin();i!=Path.end();i++){
		auto point=*i;
	
		patharr[point.first][point.second]=1;}
				
					
	//For Finding Path				
		if(display==true)
		
		{			
		int desvertex=des;
					stack<int>last;
					
					int currentver=desvertex;
					while(currentver!=source)
					
					
		{
						//cout<<"Current vertex is : "<<currentver<<endl;
						finalstack.push(currentver);
						last.push(currentver);
						for(int i=0;i<Vertex;i++)
						{
							if(patharr[i][currentver]==1)
							{currentver=i;
							break;
							}
						}
		}
							last.push(source);
							finalstack.push(source);
							//Displaying Path
					
						cout<<"\n \n";
					
					for(int k=0;!last.empty();k++){		
							cout<<last.top();
							cout<<" --> ";
							last.pop();}
							
							
						
			}
							
			
	cout<<endl;}	
	
int main()
{

	int edges,vertex;
	cout<<"Enter Total Number of Vertex: ";
	cin>>vertex;
	vertex++;
	
    bool Recorded [vertex];
    int distance[vertex];	
    
   	  // Dynamically allocate memory for the 2D array
    int** adjmatrix = new int*[vertex];
    for (int i = 0; i < vertex; i++) 
    {
        adjmatrix[i] = new int[vertex];
    }
    	
	
	//Initilazing all values to infinity 
	for(int i=0;i<vertex;i++)
	
	{
		
		for(int j=0;j<vertex;j++)
		{
			
				adjmatrix[i][j]=infinity;
			
		}
		Recorded[i]=false;
		distance[i]=infinity;
	}

	cout<<"Enter Total Number of Edges:";
	cin>>edges;
	
	
	
	
	
	
	//Taking Input Of Edges 
	for(int i=0;i<edges;i++)
	{
		int x,y,weight;
		cout<<"Enter Edges: '(Starting vertex[integer form]   Ending vertex[integer form]   Weight)'";
		cin>>x>>y>>weight;
		
		adjmatrix[x][y]=weight;
		adjmatrix[y][x]=weight;
	}
	
	int src,desvertex;
	cout<<"Enter Source Vertex: ";
	cin>>src;
	cout<<endl;
	cout<<"\nEnter Destination Vertex: ";
	cin>>desvertex;
Dijkstras(adjmatrix,distance,Recorded,vertex,src);
cout<<"\nMinimum Distance From Source Vertex to All Vertex: \n";
for(int i=1;i<vertex;i++)
   {
	cout<<"Distance From Source Vertex to"<<" "<<i<<" is "<<distance[i]<<endl;
	
	
	
	}
	cout<<"\n\n\n";
cout<<".....................SHORTEST BEST PATH ..........................\n "<<endl;	
Path_Finder(src,vertex,desvertex,true);
cout<<"\nDISTANCE FROM BEST PATH: "<<distance[desvertex];


int count=0; //Counting Total Number of  Additional Path 
set<pair<int,int>> Shortest_Path;
while(!finalstack.empty()){
	
		int point_first=finalstack.top();
		finalstack.pop();
		int point_second=finalstack.top();
		finalstack.pop();
		count++;

	     Shortest_Path.insert(make_pair(point_first,point_second));
		
	
		
		}
		
int dist_counter[count];	   //Declare an Array For Recording Distance of All Alternate Path 
int counter=0;	
//Function For Calculating Distance of All Path 
for(auto i=Shortest_Path.begin();i!=Shortest_Path.end();i++)
{
		auto point=*i;
		
		//Storing the value of an edge which were present in the shortest path  
		int buffer=adjmatrix[point.first][point.second];  
		
		
		//Initialize the value of an edge  to infinity which were present in the shortest path  
	
	  
	   adjmatrix[point.first][point.second]=infinity;
	   adjmatrix[point.second][point.first]=infinity;
	   
	   //Now Calculating Distance from Source to Destination 
	   
	   for(int j=0;j<vertex;j++){distance[j]=infinity  ,   Recorded[j]=0;}
		Path.clear();
		
	Dijkstras(adjmatrix,distance,Recorded,vertex,src);
    cout<<endl;

	Path_Finder(src,vertex,desvertex,false);

	 adjmatrix[point.first][point.second]=buffer;
	  adjmatrix[point.second][point.first]=buffer;
	dist_counter[counter++]=distance[desvertex];
	
}




//Get the index of minimum value present in Dist_counter to get the 2nd best distance
int finalindex=findMinIndex(dist_counter,count);





//Program for Gernating 2nd best path
for(auto i=Shortest_Path.begin();i!=Shortest_Path.end();i++)
{
		auto point=*i;
		//Till final index goes to zero the loop continue
		if(finalindex==0){

											int buffer=adjmatrix[point.first][point.second];
										   adjmatrix[point.first][point.second]=infinity;
										   
										   
										   
										   for(int j=0;j<vertex;j++){distance[j]=infinity;
																							Recorded[j]=0;
																						}
										   
										   
										   Path.clear();
										   Dijkstras(adjmatrix,distance,Recorded,vertex,src);
										   cout<<"\n\n";
										   cout<<".....................2nd BEST PATH.................";
										   cout<<"\n\n";
										   Path_Finder(src,vertex,desvertex,true);
										   adjmatrix[point.first][point.second]=buffer;
										   cout<<"\n\nDISTANCE FROM 2nd BEST PATH IS : "<<distance[desvertex];
										   break;
                                        }
else{finalindex--;
	continue;}
}
}
